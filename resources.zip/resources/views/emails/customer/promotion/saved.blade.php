@component('mail::message')

As-salamu alaykum

Dear {{ $promo->name }},

Thank you for your reservation. We will contact you shortly

For any questions or clarifications,
Please contact us at
Gondal Travel | Pèlerinages Hajj & Omra | Séjours culturels

🇫🇷  0187653786 <br>
🇬🇧 00448007074285 <br>
🇺🇸 0018143008040 <br>

@endcomponent