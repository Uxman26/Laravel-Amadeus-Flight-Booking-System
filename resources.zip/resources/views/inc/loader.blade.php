<div id="loaderCustom" style="position:fixed;top:0; background: white; z-index: +9999999; width:100%; height:100%">
    <img style="max-height:200px;border-radius:5px;background:transparent;padding:4px; position: absolute;
    margin-left: auto;
    margin-right: auto;
    left: 0;
    right: 0;
    top:30%;
    text-align: center"
        src="{{ asset('assets/img/logo-old.png')}}" alt="logo">
    <i style="position: absolute;
    margin-left: auto;
    margin-right: auto;
    left: 0;
    right: 0;
    top:60%;
    text-align: center"
        class="spinner-border text-primary" role="status">
    </i>
</div>