<?php

use App\Http\Controllers\agent\DashboardController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\FlightSearchController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\LandingPageController;
use App\Http\Controllers\ReIssueController;
use App\Http\Controllers\PolicyController;
use Illuminate\Support\Facades\Route;

Route::resource('/', LandingPageController::class);


Route::get('/goto_nego', [DashboardController::class, 'goto_nego'])->name('goto_nego');
Route::get('/goto_nego_fair_qr', [DashboardController::class, 'goto_nego_fair_qr'])->name('goto_nego_fair_qr'); 

Route::prefix('flight')->name('flight.')->middleware('auth', 'agent')->group(function () {
    Route::resource('dashboard', DashboardController::class);
});
Route::resource('privacy_policies',PolicyController::class);
Route::prefix('flight')->name('flight.')->middleware('auth')->group(function () {
    Route::get('{origin}/{destination}/oneway/{flight_type}/{cdeparture}/{adult}/{children}/{infant}', [FlightSearchController::class, 'oneway'])->name('search.oneway');
    Route::get('{origin}/{destination}/return/{flight_type}/{cdeparture}/{return}/{adult}/{children}/{infant}', [FlightSearchController::class, 'return'])->name('search.return');
    Route::get('{origin1}/{destination1}/{departureDate1}/{origin2}/{destination2}/{departureDate2}/{origin3}/{destination3}/{departureDate3}/{origin4}/{destination4}/{departureDate4}/{adult}/{children}/{infant}', [FlightSearchController::class, 'multiCity'])->name('search.multiCity');

    Route::post('search/verify_price', [FlightSearchController::class, 'verify_price'])->name('search.verify_price');
    Route::resource('search', FlightSearchController::class);
    Route::resource('booking', BookingController::class);
    Route::resource('invoice', InvoiceController::class);
    Route::resource('reissue', ReIssueController::class);
});

Route::post('/flight/booking/get_passenger', [BookingController::class, 'get_passenger'])->name('flight.booking.get_passenger');
Route::get('/flight/booking/{id}/{hash}', [BookingController::class, 'ticket'])->name('flight.ticket.show.passenger');



require __DIR__ . '/auth.php';
require __DIR__ . '/admin.php';
require __DIR__ . '/agent.php';
require __DIR__ . '/footer.php';
